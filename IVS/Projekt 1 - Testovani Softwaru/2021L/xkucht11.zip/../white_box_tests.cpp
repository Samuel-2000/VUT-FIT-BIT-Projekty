//======== Copyright (c) 2021, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     White Box - Tests suite
//
// $NoKeywords: $ivs_project_1 $white_box_code.cpp
// $Author:     Samuel Kuchta <xkucht11@stud.fit.vutbr.cz>
// $Date:       $2022-03-10
//============================================================================//
/**
 * @file white_box_tests.cpp
 * @author Samuel Kuchta
 * 
 * @brief Implementace testu prace s maticemi.
 */

#include "gtest/gtest.h"
#include "white_box_code.h"

class Matice1x1 : public ::testing::Test {
protected:
    Matrix m();
};

TEST(BasicTests, MatrixConstructor_Set_Get) {
  Matrix x;
  EXPECT_EQ(x.get(0, 0), 0);
  Matrix x2(3, 3);
  EXPECT_ANY_THROW(Matrix(0, 1));
  EXPECT_FALSE(x2.set(-5, 3, 2));  // riadok 42?
  EXPECT_FALSE(x.set(1, 1, 0));
  EXPECT_TRUE(x.set(0, 0, -5));
  Matrix r_matrix = Matrix(2, 3);
  
  EXPECT_FALSE(r_matrix.set(std::vector<std::vector<double>> {
    {7, 6, 5, 9},
    {4, 2},
    {8}
  }));

  EXPECT_ANY_THROW(x2.get(-5, 3));
}

TEST(BasicTests, arithmetics) {
  Matrix x;
  Matrix x3;
  x3.set(0, 0, 2);
  Matrix result = x + x3;
  ASSERT_EQ(result.get(0, 0), 2);

  EXPECT_FALSE(result == x);
  EXPECT_TRUE(result == x3);

  Matrix l_matrix(3, 2);
  l_matrix.set(std::vector<std::vector<double>> {
    {2, 8},
    {7, 5},
    {0, 9},
  });

  Matrix r_matrix = Matrix(2, 3);
  r_matrix.set(std::vector<std::vector<double>> {
    {2, 3, 5},
    {4, 4, 1},
  });

  EXPECT_ANY_THROW(r_matrix * x);

  Matrix a;
  Matrix b;
  Matrix result3;

  result3 =  a * b;
  Matrix expect;
  EXPECT_TRUE(result3 == expect);
  EXPECT_ANY_THROW(a * r_matrix);
  EXPECT_ANY_THROW(a + r_matrix);

  Matrix result2(2, 2);
  EXPECT_NO_THROW(result2 = l_matrix * r_matrix);

  EXPECT_NO_THROW(result2 = result2 * 7);
}


TEST(BasicTests, Solve_Equation) {
  Matrix matrix = Matrix(3, 3);
  matrix.set(std::vector<std::vector<double>> {
    {4, 2, 2},
    {6, 5, 4},
    {3, 1, 7},
  });

  EXPECT_ANY_THROW(matrix.solveEquation(std::vector<double>(4, 0)));
  EXPECT_ANY_THROW(matrix.solveEquation(std::vector<double> {}));

  Matrix matrix6 = Matrix(6, 6);
  matrix6.set(std::vector<std::vector<double>> {
    {2, 2, -4, 2, 6, -2},
    {2, -1, 1, 2, 1, -3},
    {1, 3, -3, -1, 2, 1},
    {10, 4, -2, -2, 4, 2},
    {-3, -1, 2, 3, 1, 3},
    {8, 6, 2, -12, -6, -4},
  });


  std::vector<double> expected6 = {1, -2, 3, 4, 2, -1};
  EXPECT_FALSE(matrix6.solveEquation(std::vector<double> {8, 40, -30, -6, 32, -54}) == expected6);

}

TEST(BasicTests, trans_inverse) {



  Matrix matrix6 = Matrix(6, 6);
  matrix6.set(std::vector<std::vector<double>> {
    {1, 1, -2, 1, 3, -1},
    {2, -1, 1, 2, 1, -3},
    {1, 3, -3, -1, 2, 1},
    {5, 2, -1, -1, 2, 1},
    {-3, -1, 2, 3, 1, 3},
    {4, 3, 1, -6, -3, -2},
  });

  EXPECT_NO_THROW(matrix6.transpose());
  EXPECT_ANY_THROW(matrix6.inverse());


  Matrix matrix3 = Matrix(3, 3);
  matrix6.set(std::vector<std::vector<double>> {
    {1, 1, -2},
    {2, -1, 1},
    {1, 3, -3},
  });

  EXPECT_NO_THROW(matrix3.inverse());

  Matrix matrix2 = Matrix(2, 2);
  matrix2.set(std::vector<std::vector<double>> {
    {1, 1},
    {2, -1},
  });
  
  EXPECT_NO_THROW(matrix2.inverse());


  Matrix matrix1 = Matrix(1, 1);
  matrix1.set(std::vector<std::vector<double>> {
    {1},
  });

  EXPECT_NO_THROW(matrix1.inverse());
}



/*** Konec souboru white_box_tests.cpp ***/
