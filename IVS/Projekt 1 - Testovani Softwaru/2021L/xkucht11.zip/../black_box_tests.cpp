//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Red-Black Tree - public interface tests
//
// $NoKeywords: $ivs_project_1 $black_box_tests.cpp
// $Author:     Samuel Kuchta <xkucht11@stud.fit.vutbr.cz>
// $Date:       $2022-03-10
//============================================================================//
/**
 * @file black_box_tests.cpp
 * @author Samuel Kuchta
 * 
 * @brief Implementace testu binarniho stromu.
 */

#include <vector>
#include <iostream>

#include "gtest/gtest.h"

#include "red_black_tree.h"

class EmptyTree : public ::testing::Test {
	protected:
    BinaryTree tree;
};

class NonEmptyTree : public ::testing::Test {
	protected:
    virtual void SetUp() {
			int values[] = { 10, 85, 15, 70, 20, 60, 30, 50, 65, 80, 90, 40, 5, 55 };
			for(auto value : values) {
				tree.InsertNode(value);
			}
    }

    BinaryTree tree;
};



TEST_F(EmptyTree, InsertNode) {
	auto result = tree.InsertNode(8);
	EXPECT_TRUE(result.first);
	EXPECT_EQ(result.second->key, 8);

	auto result2 = tree.InsertNode(8);
	EXPECT_FALSE(result2.first);
	EXPECT_EQ(result.second, result2.second);

  auto result3 = tree.InsertNode(12);
  EXPECT_TRUE(result3.second->pParent);
  EXPECT_TRUE(result.second->pRight);
  EXPECT_EQ(result3.second->pParent, result.second);
  EXPECT_EQ(result3.second, result.second->pRight);

	EXPECT_EQ(result.second->color, BinaryTree::BLACK);
  EXPECT_EQ(result3.second->color, BinaryTree::RED);
}

TEST_F(NonEmptyTree, InsertNode) {
	auto result = tree.InsertNode(70);
	EXPECT_FALSE(result.first);
}


TEST_F(EmptyTree, DeleteNode) {
	EXPECT_FALSE(tree.DeleteNode(5));
}

TEST_F(NonEmptyTree, DeleteNode) {
	EXPECT_FALSE(tree.DeleteNode(13));
	EXPECT_FALSE(tree.DeleteNode(28));
	EXPECT_TRUE(tree.DeleteNode(80));
	EXPECT_FALSE(tree.DeleteNode(-5));
  EXPECT_TRUE(tree.DeleteNode(5));
  EXPECT_FALSE(tree.DeleteNode(5));
}


TEST_F(EmptyTree, FindNode) {
  EXPECT_TRUE(tree.FindNode(15) == NULL);
}

TEST_F(NonEmptyTree, FindNode) {
  EXPECT_TRUE(tree.FindNode(15) != NULL);
}


TEST_F(EmptyTree, GetLeafNodes) {
  std::vector<Node_t *> leafNodes;
  tree.GetLeafNodes(leafNodes);
  EXPECT_TRUE(leafNodes.empty());
}

TEST_F(NonEmptyTree, GetLeafNodes) {
  std::vector<Node_t *> leafNodes;
  tree.GetLeafNodes(leafNodes);

  for (auto uzel : leafNodes) {
    EXPECT_TRUE(uzel->pLeft == NULL);
    EXPECT_TRUE(uzel->pRight == NULL);
    EXPECT_TRUE(uzel->pParent != NULL);
  }
}


TEST_F(EmptyTree, GetAllNodes) {
  std::vector<Node_t *> allNodes;
  tree.GetAllNodes(allNodes);
  EXPECT_TRUE(allNodes.empty());
}

TEST_F(NonEmptyTree, GetAllNodes) {
  std::vector<Node_t *> allNodes;
  tree.GetAllNodes(allNodes);
  EXPECT_FALSE(allNodes.empty());
}


TEST_F(EmptyTree, GetNonLeafNodes) {
  std::vector<Node_t *> nonLeafNodes;
  tree.GetNonLeafNodes(nonLeafNodes);
  EXPECT_TRUE(nonLeafNodes.empty());
}

TEST_F(NonEmptyTree, GetNonLeafNodes) {
  std::vector<Node_t *> nonLeafNodes;
  tree.GetNonLeafNodes(nonLeafNodes);
  for (auto uzel : nonLeafNodes) {
    EXPECT_TRUE(uzel->pLeft || uzel->pRight);
  }
}


TEST_F(EmptyTree, GetRoot) {
  EXPECT_TRUE(tree.GetRoot() == NULL);
}


TEST_F(NonEmptyTree, GetRoot) {
  BinaryTree::Node_t * Root = tree.GetRoot();
  ASSERT_TRUE(Root != NULL);
  EXPECT_TRUE(Root->pParent == NULL);
  ASSERT_TRUE(Root->pLeft != NULL);
  ASSERT_TRUE(Root->pRight != NULL);
}


TEST_F(NonEmptyTree, TreeAxioms) {  // Axiomy (tedy vzdy platne vlastnosti) Red-Black Tree:
  // AXIOM1: Vsechny listove uzly stromu jsou *VZDY* cerne.
  std::vector<Node_t *> Nodes;
  tree.GetLeafNodes(Nodes);
  for (auto uzel : Nodes) {
    EXPECT_EQ(uzel->color, BinaryTree::BLACK);
  }

  // AXIOM2: Kazdy cerveny uzel muze mit *POUZE* cerne potomky.
  tree.GetAllNodes(Nodes);
  for (auto uzel : Nodes) {
    if (uzel->color == BinaryTree::RED) {
      ASSERT_TRUE(uzel->pLeft != NULL);
      EXPECT_EQ(uzel->pLeft->color, BinaryTree::BLACK);
      ASSERT_TRUE(uzel->pRight != NULL);
      EXPECT_EQ(uzel->pRight->color, BinaryTree::BLACK);
    }
  }

  // AXIOM3: Vsechny cesty od kazdeho listoveho uzlu ke koreni stromu obsahuji *STEJNY* pocet cernych uzlu.
  tree.GetLeafNodes(Nodes);
  int blackNodesCount, prevBlackNodesCount = -42;
  Node_t *currNode;
  for (auto uzel : Nodes) {
    blackNodesCount = 0;
    currNode = uzel;
    while (currNode) {
      if (currNode->color == BinaryTree::BLACK) {
        blackNodesCount++;
      }
      currNode = currNode->pParent;
    }
    if (prevBlackNodesCount != -42) {
      EXPECT_EQ(prevBlackNodesCount, blackNodesCount);
    }
    prevBlackNodesCount = blackNodesCount;
  }
}

/*** Konec souboru black_box_tests.cpp ***/
