//======== Copyright (c) 2021, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Test Driven Development - priority queue code
//
// $NoKeywords: $ivs_project_1 $tdd_tests.cpp
// $Author:     Samuel Kuchta <xkucht11@stud.fit.vutbr.cz>
// $Date:       $2022-03-06
//============================================================================//
/**
* @file tdd_code.cpp
* @author Samuel Kuchta
* 
* @brief Implementace metod tridy prioritni fronty.
 */

#include <stdlib.h>
#include <stdio.h>

#include "tdd_code.h"

//============================================================================//
// ** ZDE DOPLNTE IMPLEMENTACI **
//
// Zde doplnte implementaci verejneho rozhrani prioritni fronty (Priority Queue)
// 1. Verejne rozhrani fronty specifikovane v: tdd_code.h (sekce "public:")
//    - Konstruktor (PriorityQueue()), Destruktor (~PriorityQueue())
//    - Metody Insert/Remove/Find/GetHead ...
//    - Pripadne vase metody definovane v tdd_code.h (sekce "protected:")
//
// Cilem je dosahnout plne funkcni implementace prioritni fronty implementovane
// pomoci tzv. "singly linked list", ktera bude splnovat dodane testy
// (tdd_tests.cpp).
//============================================================================//

PriorityQueue::PriorityQueue() {
    m_pHead = NULL;
}

PriorityQueue::~PriorityQueue() {
  Element_t* element = GetHead(); // prochazeni fronty od zacatku
  Element_t* temp_element;
  while (element != NULL) {
    temp_element = element; // ulozeni ukazatele polozky do docasne promenne, abychom ji potom mohli odstranit
    element = element->pNext; // uvolneni polozky z pameti
    delete temp_element;
  }
}


void PriorityQueue::Insert(int value) {
  
  if(GetHead() != NULL) { // neprazdny seznam
    Element_t* element_prev = NULL;
    Element_t* element = GetHead();
    while(element != NULL || element_prev != NULL) { // prochazeni fronty od zacatku
      if (element == NULL) {  // na konci fronty
        Element_t* novy = new Element_t();
        element_prev->pNext = novy;
        novy->value = value;
        return;
      }
      if (element->value <= value) { // prvek muzeme zaradit do fronty
        Element_t* novy = new Element_t(); // vytvori prvek, ktery ukazuje na dalsi prvek.
        if(element_prev != NULL) { // uprostred fronty
          element_prev->pNext = novy; // predchozi ukazuje na novy
          novy->pNext = element;
        } else { // zacatek fronty
          novy->pNext = m_pHead;
          m_pHead = novy;
        }
        novy->value = value;
        return;
      } else if (element->value > value) {
        element_prev = element;
        element = element->pNext; // hledam prvek dal ve frontě
      } else {  // prvek je mensi nez hledany
        break; // prvek je nejmensi
      }
    }
  }
  m_pHead = new Element_t(); // vytvori 1. prvek.
  m_pHead->value = value;
  m_pHead->pNext = NULL;
}

bool PriorityQueue::Remove(int value) {
  Element_t* element = GetHead();
  Element_t* prev_element_pointer = NULL;
  while(element != NULL) { // prochazeni fronty od zacatku
    if (element->value == value) { // prvek byl nalezen
      if(prev_element_pointer == NULL) {
        prev_element_pointer = GetHead();
      }
      prev_element_pointer->pNext = element->pNext; // prvek ktery ukazoval na me, ted ukazuje prede me.
     /* if ((element->pNext == NULL) && (m_pHead == element)) {  // ak je posledny prvok
        m_pHead == NULL; // wtffffffffffffffff
      }*/
      m_pHead = m_pHead->pNext;
      delete element;

      return true;
    } else if (element->value > value) { // hledam prvek dal ve frontě
      prev_element_pointer = element;
      element = element->pNext;
    } else {
      return false; // prvek nebyl nalezen, uz jsou jenom mensi nebo zadne prvky
    }
  }
  return false;
}

PriorityQueue::Element_t* PriorityQueue::Find(int value) {
  Element_t* element = GetHead();
  while(element != NULL) { // prochazeni fronty od zacatku
    if (element->value == value) { // prvek byl nalezen
      return element;
    }
    if (element->value > value) { // hledam prvek dal ve frontě
      element = element->pNext;
    } else {
      return NULL; // prvek nebyl nalezen, uz jsou jenom mensi nebo zadne prvky
    }
  }
  return NULL;
}

size_t PriorityQueue::Length() {
  size_t i = 0;
  Element_t* ptr = GetHead();
  while(ptr != NULL) {
    ptr = ptr->pNext;
    i++;
  }
  return i;
}

PriorityQueue::Element_t* PriorityQueue::GetHead() {
  return m_pHead;
}

PriorityQueue::Element_t* PriorityQueue::NewElement(int value, Element_t* pNext) {
  Element_t* element = new Element_t();
  element->value = value;
  element->pNext = pNext;
  return element;
}

/*** Konec souboru tdd_code.cpp ***/
